import { Component } from '@angular/core';

@Component({
  selector: 'app-acceptable-use-policy',
  standalone: true,
  imports: [],
  templateUrl: './acceptable-use-policy.component.html',
  styleUrl: './acceptable-use-policy.component.css'
})
export class AcceptableUsePolicyComponent {

}
