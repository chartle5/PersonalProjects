import { Component } from '@angular/core';

@Component({
  selector: 'app-dmca-policy',
  standalone: true,
  imports: [],
  templateUrl: './dmca-policy.component.html',
  styleUrl: './dmca-policy.component.css'
})
export class DmcaPolicyComponent {

}
